# recreate-studio

> 短剧素材 → **全自动二创成片**：封面片头、按台词完整句下刀、原声全保留、右上角水印、9:16 竖屏、约 180 秒。

给 AI agent（DeepSeek Harness skill 格式）使用，也可直接调用 `scripts/recreate.py`。

## 能实现什么

- **封面片头**：取素材目录里的封面图，铺满画布做 2.5 秒缓慢推近（`--no-cover` 可关）
- **按完整句下刀**：`faster-whisper`（medium）转写每条素材拿句级时间戳，候选段由连续完整句组成，**起点=句首、终点=句尾**，不切断人物台词；缓存 `<clip>.asr.json`，重剪秒级
- **高燃选段**：音频能量 0.6 + 画面运动 0.4 打分，挑 18–20 段，按强度由弱到强
- **原声全保留**：原声 1.0 主轨；BGM 0.12 由原声侧链闪避，台词不被压
- **字幕**：默认保留源片自带硬字幕，**不额外烧录**（避免重影/遮挡）；`--subtitles` 为实验选项（ASR 字幕）
- **水印**：右上角半透明账号水印（`--watermark "@账号"`）
- **音画同步**：每段强制 300 帧（10.000s）+ 音频 `apad/atrim` 等长；concat 视频 copy、音频重编码；不用 `loudnorm`
- **规格**：默认 9:16（1080×1920），可 `16:9`/`1:1`/`19:6`/`WxH`
- **批量**：`--root` 遍历，已有成片自动跳过，`--force` 重剪
- **报告**：JSON（时长/句级对齐/原声/水印/合规项/每段高燃分数）

## 目录结构

```
recreate-studio/
├── SKILL.md                      # 技能主文档（流程、校验、强制规则）
├── references/
│   ├── editing-recipe.md         # FFmpeg 配方：句级切点、封面片头、音轨链、字幕
│   ├── compliance-douyin.md      # 抖音二创审核要点与发布 SOP
│   └── download-stage.md         # 阶段 0：素材下载（Playwright + BaiduPCS-Go）
├── scripts/
│   ├── recreate.py               # 核心渲染器（含 BGM 来源清单与自动下载）
│   └── 一键二创_碧海剧场.bat        # Windows 双击批处理（调用 recreate.py）
└── README.md
```

## 依赖

| 依赖 | 说明 |
|---|---|
| Python 3.10+ | `numpy`、`faster-whisper`（句级切点必需） |
| FFmpeg / ffprobe | 6.0+，含 libx264/libass |
| ASR 模型 | 默认 `medium`（首次下载约 1.5GB，CPU 约 0.7x 实时） |
| BGM | 自备 7 种情绪 mp3（版权原因不附带） |
| 字体 | `C:\Windows\Fonts\msyh.ttc` |

```bash
pip install numpy faster-whisper
```

## BGM（内嵌自动部署）

- 解析顺序：`RECREATE_BGM_DIR` → 桌面 `漫剧短剧BGM库` → 技能 `assets/bgm`
- 目录为空时，`recreate.py` 用**内置的 39 首来源清单**从 Mixkit / Incompetech 直接下载（约 200MB），并生成 10 分类 + `index.json` 情绪映射
- 单独准备：`python scripts/recreate.py --setup-bgm`（`--bgm-limit 2` 可试跑）
- 许可：Mixkit 免署名可商用；Incompetech CC BY 4.0，成片需署名 `Kevin MacLeod (incompetech.com)`
- 仓库不附带音频文件

## 用法

```bash
# 单部
python scripts/recreate.py --folder "<LIBRARY_ROOT>/001. 剧名" --watermark "@你的账号"

# 批量
python scripts/recreate.py --root "<LIBRARY_ROOT>" --watermark "@你的账号"
```

Windows 双击/命令行：

```bat
一键二创_碧海剧场.bat "D:\碧海剧场" 1 force
```

| 参数 | 说明 |
|---|---|
| `--folder` / `--root` | 单部 / 批量 |
| `--aspect` | `9:16`（默认）/`16:9`/`1:1`/`19:6`/`WxH` |
| `--duration` | 目标秒数（默认 180） |
| `--watermark` | 水印文案（右上角） |
| `--subtitles` | 额外烧录 ASR 字幕（默认关，保留源字幕） |
| `--tts` | 加 AI 解说（默认关） |
| `--no-cover` | 不用封面片头 |
| `--keep-src-subs` | 不铺字幕条（配合 `--subtitles` 时用） |
| `--force` | 覆盖已有成片 |

环境变量：`RECREATE_FFMPEG`、`RECREATE_FFPROBE`、`RECREATE_BGM_DIR`、`RECREATE_FONT`、`RECREATE_ASR_MODEL`。

## 输出

```
<素材文件夹>/
├── <剧名>_二创_3min.mp4
├── <剧名>_二创_报告.json
└── *.mp4.asr.json      # ASR 缓存，可复用
```

## 合规提醒

只处理自己账号、已获授权或平台允许推广的素材；含 AI 合成内容按平台要求勾选「内容由AI生成」；不承诺 100% 过审。

## 版本

- **v1.9（2026-10-26）**：随机化去重（时长/fps/段长/缩放/调色/颗粒/水印字号），同素材每次成片不同
- v1.8：单文件脚本，BGM 来源清单与下载逻辑内嵌
- v1.6：句级切点（ASR medium）、原声 1.0 全保留 + BGM 侧链闪避、默认保留源字幕不烧录、水印右上角
- v1.3：音画同步修复（300 帧/段、音频等长、concat 音频重编码、去 loudnorm）
- v1.2：封面片头、高燃选段
- v1.0：下载 + 二创基础流水线

## License

暂未声明许可证；如需开源建议补 MIT。
