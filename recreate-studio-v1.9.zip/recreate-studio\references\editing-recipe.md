﻿# 剪辑配方（FFmpeg 细节）

## 画布与比例

| 预设 | 像素 | 适用 |
|---|---|---|
| `9:16`（默认） | 1080×1920 | 抖音竖屏主流 |
| `16:9` | 1920×1080 | 横屏/B站 |
| `1:1` | 1080×1080 | 方图 |
| `19:6`（可选） | 1920×608 | 超宽，竖屏素材两侧大面积虚化；仅特殊需求 |

自定义：`--aspect 1280x720`（自动取偶）。

## 封面片头（默认 2.5s）

- 素材目录里任取一张图片（优先名字含 封面/cover/海报，否则第一张图）。
- 铺满画布（`scale=increase,crop`）+ 缓慢推近（`zoompan z 从 1 到 1.08`），30fps。
- 必须带静音音轨（`anullsrc`），否则与正片段 concat 时音画流不一致。
- 片头占 2.5s，正片段按 `180 - 2.5 = 177.5s` 重新均分（仍是 18 段）。
- 关闭：`--no-cover`。

## 高燃选段 + 句级切点（默认）

源片字幕已烧在画面上，切在句子中间会出现“半句台词/半句字幕”。规则：

1. **ASR 句级时间戳（优先）**：`faster-whisper`（默认 medium）转写每条素材，得到每句 start/end，缓存为 `<clip>.asr.json`；ASR 不可用时只用 `silencedetect` 静音中点，**禁用镜头切点**（会切进句子）。
2. 候选窗口 = 连续完整句的组合，8–12s，**起点=句首、终点=句尾**。
3. 打分：音频能量 0.6 + 画面运动 0.4（各取 90 分位归一化），贪心选 18–20 段，同集不重叠、单集上限；按分数**升序**排列。
4. 时长用统一缩放系数（0.85–1.15）压到正片目标时长；变速同时作用于画面与音频（见下）。

报告写 `sentence_aligned=true`、`cut_aligned=true`、`asr_model`、`segment_durations`。
依赖 `faster-whisper` + medium 模型（首次自动下载约 1.5GB，CPU 约 0.7x 实时；缓存命中后秒级）。

## 分段规划

- 目标总长 `--duration 180`；有封面片头时正片 = `180 - 2.5`，段数 `n = round(正片/10) = 18`。
- 每段输出 8–12s（按切点），变速循环 `1.0 / 1.04 / 0.96`。
- **变速必须作用在整段**：`setpts=(1/speed)*PTS` 放在 `split` **之前**（背景与前景一起变速），音频用 `atempo=speed`；否则 `overlay:shortest=1` 会让视频提前结束、音频继续 → 音画错位。
- 起点/终点都取切点（静音中点或镜头切换点），不再随机取点，避免切断台词。
- 拼接：视频 `-c:v copy`、音频**重新编码**（`-c:a aac`）+ `-fflags +genpts`，避免 AAC 拼接累积漂移；不要用 `-c copy` 同时拷音频。

## 单段滤镜链

```
[0:v]setpts=(1/speed)*PTS,fps=30,split=2[bg][fg];
[bg]scale=W/4:H/4,gblur=sigma=12,scale=W:H,setsar=1[bgv];
[fg]scale=W:H:force_original_aspect_ratio=decrease,[hflip,]setsar=1[fgv];
[bgv][fgv]overlay=(W-w)/2:(H-h)/2,
  eq=contrast=1.05:saturation=1.12,vignette=PI/6,noise=alls=4:allf=t+u,
  tpad=stop_mode=clone:stop_duration=1,format=yuv420p[v]
```

- 背景先缩到 1/4 再模糊再放大：速度快、效果够。
- 镜像默认**关闭**（`--mirror` 开启）：源片自带硬字幕，镜像后会变成反字，影响观感与审核。
- `noise` 颗粒 + `vignette` 暗角：统一质感。
- **帧数对齐**：输出加 `-frames:v round(10*30)=300`、`-t 10.2`（留余量），并在音频侧 `aresample=44100,apad,atrim=0:10.000`，保证每段视频 300 帧=10.000s、音频 10.000s；只靠 `-t 10` 会因时间戳取整少 1 帧（299 帧），18 段累计约 0.6s 漂移。

## 音画同步检查清单（交付前）

1. 随机抽 3 段中间产物，`ffprobe` 两路流：视频 `nb_frames = 300`、音频 `duration = 10.000`。
2. 成片：视频时长与音频时长差 < 0.1s。
3. 变速段（1.04/0.96）也要满足上面两条。
4. 播放时抽查：人物口型与台词、硬字幕与语音应对齐。

## 终混（视频）

```
drawtext=fontfile='C\:/Windows/Fonts/msyh.ttc':text='@账号':
  fontsize=H/28:fontcolor=white@0.55:x=w-tw-24:y=h-th-24:
  shadowcolor=black@0.45:shadowx=1:shadowy=1
subtitles=subs.srt:force_style='FontName=Microsoft YaHei,FontSize=<units>,
  PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,
  Outline=<ol>,Shadow=0,MarginV=<mv>,Alignment=2'
```

⚠ **libass 单位陷阱**：`subtitles` 滤镜的 `force_style` 以 288 行为基准缩放，
直接写像素会放大 `H/288` 倍（1080×1920 上会变成巨字、边距被顶到画面顶部）。换算：

```
scale = 288 / H
FontSize(units) = round(期望像素字号 × scale)      # 期望字号 ≈ max(22, H/36)
MarginV(units) = round(期望底部边距 × scale)       # 期望边距 ≈ max(60, H/8)
Outline(units) = max(1, round(3 × scale))
```

- 水印半透明、右上角，字号随画布高度缩放（drawtext 不含该缩放问题）。
- 字幕按画布高度定字号，底部居中。

## 音频链（解说 + BGM 闪避 + 原声）

```
[nar]volume=1.0,aresample=44100[nar];
[bgm]volume=0.16,atrim=0:180[bgm];
[nar]asplit=2[n1][key];
[bgm][key]sidechaincompress=threshold=0.03:ratio=12:attack=15:release=350[duck];
[orig]volume=0.12;
[n1][duck][orig]amix=inputs=3:duration=longest:normalize=0,apad,atrim=0:{total}[a]
```

- BGM 用 `-stream_loop -1` 循环后 `atrim` 到目标时长。
- **默认无解说**：原声 **1.0 全音量** + BGM 0.12，BGM 用原声侧链闪避，台词不被压。
- 加 `--tts` 时：解说 1.0 + 原声 0.7 + BGM 0.12 侧链闪避（`sidechaincompress`），并烧录逐句字幕。
- **不要用 `loudnorm`**：它会引入额外音频延迟，造成音画轻微错位；改用 `apad,atrim=0:total` 把音轨精确压到成片时长，响度靠各路 `volume` 控制。

## 情绪 → BGM 映射

| 关键词命中 | 情绪 |
|---|---|
| 甜/恋/婚/宠/爱/暖/春 | 温柔 |
| 悬/秘/谜/真相/阴/局 | 悬疑（默认） |
| 总裁/复仇/逆袭/打脸/豪门/狂/龙/殿 | 激昂 |
| 逃/追/危/杀/绑/劫/惊 | 紧张 |
| 仙/灵/玄/梦/古/云/凤 | 空灵 |
| 笑/萌/团宠/福宝/搞笑/宝/娃 | 轻快 |
| 离/别/死/哭/遗/孤/悔 | 悲伤 |

BGM 目录：`<BGM_DIR>`（可用 `RECREATE_BGM_DIR` 覆盖）。

## 编码参数

- 分段：`libx264 -preset veryfast -crf 20`，AAC 128k 44.1kHz 立体声，`-video_track_timescale 90000`（保证 concat 兼容）。
- 终版：`libx264 -preset medium -crf 19`，AAC 192k，`-movflags +faststart`，`yuv420p`。
- 帧率统一 30fps；`-t 180` 硬截断，防音频拖长。

## 可调项

- 成片更长/更短：`--duration`。
- 段更长（节奏更慢）：改脚本 `seg_len` 默认 10.0。
- 更强的风格化：调 `eq` 饱和度/对比度、`vignette` 角度、`noise` 强度。
- 解说文案：目前模板生成；后续可加 `--script-file`（TODO）。
- 水印位置/透明度：改 `final_render` 的 drawtext 表达式。
