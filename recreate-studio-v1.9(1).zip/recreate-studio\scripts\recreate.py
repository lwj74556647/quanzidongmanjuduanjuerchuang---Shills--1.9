# -*- coding: utf-8 -*-
"""recreate-studio 渲染器：把一集短剧素材自动剪成约 3 分钟的抖音二创成片。

用法：
  py recreate.py --folder "D:\\碧海剧场\\001. 毒酒换红妆"
  py recreate.py --root   "D:\\碧海剧场" --limit 3
  py recreate.py --folder ... --aspect 9:16 --duration 180 --watermark "@账号名"

产出：<素材文件夹>\\<剧名>_二创_3min.mp4 与 <剧名>_二创_报告.json
"""
import argparse
import json
import math
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

__version__ = "1.9"

try:
    import numpy as np
except Exception:  # numpy 缺失时退化为随机选段
    np = None

def _first(*paths):
    """按顺序返回第一个存在的文件/命令；都没有则返回最后一个（可能只是命令名）。"""
    for p in paths:
        if p and (os.path.isfile(p) or shutil.which(p)):
            return p
    return paths[-1]


def _first_dir(*paths):
    for p in paths:
        if p and os.path.isdir(p):
            return p
    return ""


FFMPEG = os.environ.get("RECREATE_FFMPEG") or _first(r"D:\AI\tools\ffmpeg.exe", "ffmpeg")
FFPROBE = os.environ.get("RECREATE_FFPROBE") or _first(r"D:\AI\tools\ffprobe.exe", "ffprobe")
BGM_DIR = os.environ.get("RECREATE_BGM_DIR") or _first_dir(
    os.path.join(os.path.expanduser("~"), "Desktop", "漫剧短剧BGM库"),
    r"D:\deepseek漫剧1\studio\assets\bgm",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets", "bgm"),
)
FONT = os.environ.get("RECREATE_FONT", r"C:\Windows\Fonts\msyh.ttc")
FONT_ESC = FONT.replace("\\", "/").replace(":", "\\:")

# 内嵌 BGM 来源清单（Mixkit 免署名 / Incompetech CC-BY），首次运行自动下载
BGM_SOURCES = [
    ('01_甜宠暧昧｜恋爱撒糖/01_Beautiful Dream.mp3', 'https://assets.mixkit.co/music/493/493.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/02_Skyline.mp3', 'https://assets.mixkit.co/music/601/601.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/03_Romantic.mp3', 'https://assets.mixkit.co/music/659/659.mp3'),
    ('01_甜宠暧昧｜恋爱撒糖/04_Latin Lovers.mp3', 'https://assets.mixkit.co/music/39/39.mp3'),
    ('02_虐心BE｜遗憾回忆/01_Silent Descent.mp3', 'https://assets.mixkit.co/music/614/614.mp3'),
    ('02_虐心BE｜遗憾回忆/02_Sun and His Daughter.mp3', 'https://assets.mixkit.co/music/580/580.mp3'),
    ('02_虐心BE｜遗憾回忆/03_Piano Reflections.mp3', 'https://assets.mixkit.co/music/22/22.mp3'),
    ('02_虐心BE｜遗憾回忆/04_Classical vibes 5.mp3', 'https://assets.mixkit.co/music/688/688.mp3'),
    ('02_虐心BE｜遗憾回忆/05_Classical 7.mp3', 'https://assets.mixkit.co/music/714/714.mp3'),
    ('03_高燃逆袭｜打脸高光/01_Epic Unease.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Epic%20Unease.mp3'),
    ('03_高燃逆袭｜打脸高光/02_Heroic Age.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Heroic%20Age.mp3'),
    ('03_高燃逆袭｜打脸高光/03_Take the Lead.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Take%20the%20Lead.mp3'),
    ('03_高燃逆袭｜打脸高光/04_Rynos Theme.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Rynos%20Theme.mp3'),
    ('04_悬疑反转｜伏笔惊悚/01_Dark Fog.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Dark%20Fog.mp3'),
    ('04_悬疑反转｜伏笔惊悚/02_Hidden Agenda.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Hidden%20Agenda.mp3'),
    ('04_悬疑反转｜伏笔惊悚/03_Anxiety.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Anxiety.mp3'),
    ('04_悬疑反转｜伏笔惊悚/04_Ossuary 5 - Rest.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ossuary%205%20-%20Rest.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/01_Secret Garden.mp3', 'https://assets.mixkit.co/music/595/595.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/02_Games Worldbeat.mp3', 'https://assets.mixkit.co/music/466/466.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/03_Upbeat Jazz.mp3', 'https://assets.mixkit.co/music/644/644.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/04_Comical.mp3', 'https://assets.mixkit.co/music/2/2.mp3'),
    ('05_轻松搞笑｜乌龙吃瓜/05_Keep Smiling.mp3', 'https://assets.mixkit.co/music/15/15.mp3'),
    ('06_古风仙侠｜江湖权谋/01_Eastern Thought.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Eastern%20Thought.mp3'),
    ('06_古风仙侠｜江湖权谋/02_Ishikari Lore.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ishikari%20Lore.mp3'),
    ('06_古风仙侠｜江湖权谋/03_Tabuk.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Tabuk.mp3'),
    ('06_古风仙侠｜江湖权谋/04_Desert City.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Desert%20City.mp3'),
    ('07_治愈日常｜温柔叙事/01_Serene View.mp3', 'https://assets.mixkit.co/music/443/443.mp3'),
    ('07_治愈日常｜温柔叙事/02_Valley Sunset.mp3', 'https://assets.mixkit.co/music/127/127.mp3'),
    ('07_治愈日常｜温柔叙事/03_Classical vibes 2.mp3', 'https://assets.mixkit.co/music/682/682.mp3'),
    ('07_治愈日常｜温柔叙事/04_Wedding 01.mp3', 'https://assets.mixkit.co/music/657/657.mp3'),
    ('07_治愈日常｜温柔叙事/05_Relax Beat.mp3', 'https://assets.mixkit.co/music/292/292.mp3'),
    ('08_反派压迫｜阴郁暗黑/01_Ghost Story.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ghost%20Story.mp3'),
    ('08_反派压迫｜阴郁暗黑/02_Ossuary 6 - Air.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Ossuary%206%20-%20Air.mp3'),
    ('08_反派压迫｜阴郁暗黑/03_Come Play with Me.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Come%20Play%20with%20Me.mp3'),
    ('08_反派压迫｜阴郁暗黑/04_Darkest Child.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Darkest%20Child.mp3'),
    ('09_卡点预告｜片头片尾/01_Prelude and Action.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Prelude%20and%20Action.mp3'),
    ('09_卡点预告｜片头片尾/02_Killers.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Killers.mp3'),
    ('09_卡点预告｜片头片尾/03_Impact Prelude.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Impact%20Prelude.mp3'),
    ('09_卡点预告｜片头片尾/04_Impact Moderato.mp3', 'https://incompetech.com/music/royalty-free/mp3-royaltyfree/Impact%20Moderato.mp3'),
]


ASPECTS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "19:6": (1920, 608),
    "1:1": (1080, 1080),
}

MOODS = [
    ("温柔", ("甜", "恋", "婚", "宠", "爱", "暖", "春")),
    ("悬疑", ("悬", "秘", "谜", "真相", "阴", "局")),
    ("激昂", ("总裁", "复仇", "逆袭", "打脸", "豪门", "狂", "龙", "殿")),
    ("紧张", ("逃", "追", "危", "杀", "绑", "劫", "惊")),
    ("空灵", ("仙", "灵", "玄", "梦", "古", "云", "凤")),
    ("轻快", ("笑", "萌", "团宠", "福宝", "搞笑", "宝", "娃")),
    ("悲伤", ("离", "别", "死", "哭", "遗", "孤", "悔")),
]


def decode(b):
    if not b:
        return ""
    for enc in ("utf-8", "gbk"):
        try:
            s = b.decode(enc)
            if "\ufffd" not in s:
                return s
        except Exception:
            pass
    return b.decode("gbk", errors="replace")


def run(cmd, cwd=None, timeout=7200):
    p = subprocess.run(cmd, capture_output=True, cwd=cwd, timeout=timeout)
    return p.returncode, decode(p.stdout), decode(p.stderr)


def probe(path):
    rc, out, _ = run([FFPROBE, "-v", "error", "-print_format", "json",
                      "-show_format", "-show_streams", path], timeout=120)
    if rc != 0:
        return {}
    j = json.loads(out)
    v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), {})
    a = next((s for s in j.get("streams", []) if s.get("codec_type") == "audio"), None)
    return {
        "width": int(v.get("width") or 0),
        "height": int(v.get("height") or 0),
        "fps": v.get("r_frame_rate") or "25/1",
        "duration": float(j.get("format", {}).get("duration") or 0),
        "has_audio": a is not None,
    }


def parse_aspect(text):
    text = text.strip()
    if text in ASPECTS:
        return ASPECTS[text]
    m = re.match(r"^(\d+)[xX:：](\d+)$", text)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
        w -= w % 2
        h -= h % 2
        return w, h
    raise ValueError("aspect 需为 9:16/16:9/19:6/1:1 或 WxH")


def pick_mood(title):
    for mood, keys in MOODS:
        if any(k in title for k in keys):
            return mood
    return "悬疑"


BGM_MOODS = {
    "悬疑": ["04_悬疑反转｜伏笔惊悚"],
    "紧张": ["04_悬疑反转｜伏笔惊悚", "03_高燃逆袭｜打脸高光"],
    "悲伤": ["02_虐心BE｜遗憾回忆"],
    "温柔": ["01_甜宠暧昧｜恋爱撒糖", "07_治愈日常｜温柔叙事"],
    "激昂": ["03_高燃逆袭｜打脸高光", "09_卡点预告｜片头片尾"],
    "空灵": ["06_古风仙侠｜江湖权谋", "07_治愈日常｜温柔叙事"],
    "轻快": ["05_轻松搞笑｜乌龙吃瓜"],
}

BGM_LICENSE = """# BGM 许可说明

- Mixkit Stock Music Free License：可商用、免署名、不可转售原始音频。
- Incompetech / Kevin MacLeod — CC BY 4.0：可商用，成片需署名
  `Music by Kevin MacLeod (incompetech.com), licensed under CC BY 4.0`
"""


def ensure_bgm(limit=0, force=False):
    """BGM 目录缺失/为空时，按内嵌来源清单从原始地址下载（约 39 首，200MB）。"""
    os.makedirs(BGM_DIR, exist_ok=True)
    idx_path = os.path.join(BGM_DIR, "index.json")
    if os.path.isfile(idx_path) and not force:
        try:
            data = json.load(open(idx_path, encoding="utf-8"))
            if any(data.get(m) for m in BGM_MOODS):
                return
        except Exception:
            pass
    ok = skip = fail = 0
    for rel, url in BGM_SOURCES:
        if limit and ok + skip >= limit:
            break
        dst = os.path.join(BGM_DIR, rel.replace("/", os.sep))
        if os.path.isfile(dst) and not force:
            skip += 1
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=90) as r, open(dst, "wb") as f:
                f.write(r.read())
            ok += 1
            print(f"BGM 下载 {rel}", flush=True)
        except Exception as e:
            fail += 1
            print(f"BGM 失败 {rel}: {e}", flush=True)
    index = {}
    for mood, dirs in BGM_MOODS.items():
        index[mood] = [rel for rel, _ in BGM_SOURCES
                       if os.path.dirname(rel) in dirs
                       and os.path.isfile(os.path.join(BGM_DIR, rel.replace("/", os.sep)))]
    with open(idx_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=1)
    with open(os.path.join(BGM_DIR, "LICENSE.md"), "w", encoding="utf-8") as f:
        f.write(BGM_LICENSE)
    print(f"BGM 就绪：{BGM_DIR}（下载 {ok}，跳过 {skip}，失败 {fail}）", flush=True)


def pick_bgm(title):
    mood = pick_mood(title)
    idx = os.path.join(BGM_DIR, "index.json")
    if os.path.isfile(idx):
        try:
            data = json.load(open(idx, encoding="utf-8"))
            files = data.get(mood) or []
            cands = [os.path.join(BGM_DIR, f.replace("/", os.sep)) for f in files]
            cands = [p for p in cands if os.path.isfile(p)]
            if cands:
                return mood, random.choice(cands)
        except Exception:
            pass
    p = os.path.join(BGM_DIR, f"{mood}.mp3")      # 兼容旧的 7 个情绪文件
    return mood, (p if os.path.isfile(p) else "")


HOOKS = [
    "开头三秒就把人拽进戏里，信息量拉满。",
    "这一段的张力，隔着屏幕都能感觉到。",
    "别眨眼，接下来的反转来得很快。",
    "这场对手戏，每一句都在互相试探。",
    "看到这里才明白，前面全是铺垫。",
]
BEATS = [
    "人物关系一上来就绷紧，谁在算计谁，一眼看不透。",
    "一个关键选择，把所有人的位置重新洗牌。",
    "表面风平浪静，暗地里每一步都在做局。",
    "情绪被推到顶点，台词一句比一句扎心。",
    "真正的高手，不吵不闹，只用结果说话。",
]
TAILS = [
    "后面还有更大的局，接着往下看。",
    "这一局谁输谁赢，下一段见分晓。",
    "故事才刚开始，真正的底牌还没亮。",
]


def make_commentary(title, seed):
    rnd = random.Random(seed)
    parts = [f"注意看，这部《{title}》" + rnd.choice(HOOKS)]
    picked = rnd.sample(BEATS, 4)
    parts += picked
    parts.append("故事走到这里，已经不是谁对谁错的问题，而是谁能先一步看清局面。")
    parts += rnd.sample([b for b in BEATS if b not in picked], 2)
    parts.append(rnd.choice(TAILS))
    text = "".join(parts)
    while len(text) < 320:
        pool = [b for b in BEATS if b not in text]
        text += rnd.choice(pool) if pool else rnd.choice(BEATS)
    return text


def tts(text, out_mp3, voice):
    script = "import sys, asyncio, edge_tts\n" \
             "text, voice, out = sys.argv[1], sys.argv[2], sys.argv[3]\n" \
             "async def main():\n" \
             "    c = edge_tts.Communicate(text, voice)\n" \
             "    await c.save(out)\n" \
             "asyncio.run(main())\n"
    rc, _, err = run([sys.executable, "-c", script, text, voice, out_mp3], timeout=300)
    if os.path.isfile(out_mp3) and os.path.getsize(out_mp3) > 1024:
        return True, ""
    return False, err[-500:]


def split_sentences(text, max_len=18):
    parts = re.split(r"(?<=[。！？!?；;])", text)
    out = []
    for p in parts:
        p = p.strip()
        while len(p) > max_len:
            out.append(p[:max_len])
            p = p[max_len:]
        if p:
            out.append(p)
    return out


def write_srt(sentences, total_dur, path):
    weights = [max(1, len(s)) for s in sentences]
    unit = total_dur / sum(weights)
    t = 0.0
    lines = []
    for i, s in enumerate(sentences, 1):
        d = weights[i - 1] * unit
        lines.append(f"{i}\n{fmt_ts(t)} --> {fmt_ts(t + d - 0.05)}\n{s}\n")
        t += d
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def fmt_ts(t):
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".", ",")


def _ass_ts(t):
    t = max(0.0, float(t))
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h:d}:{m:02d}:{s:05.2f}"


def write_ass(items, W, H, path, fs_factor=0.046):
    """items: [(start, end, text)]。ASS 自带 PlayRes，单位即像素，避免 libass 288 缩放。"""
    fs = max(18, int(round(H * fs_factor)))
    outline = max(2, int(round(H * 0.0028)))
    mv = int(round(H * 0.16))
    ml = int(round(W * 0.06))
    head = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {W}",
        f"PlayResY: {H}",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        f"Style: Default,Microsoft YaHei,{fs},&H00FFFFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,{outline},1,2,{ml},{ml},{mv},1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    body = []
    for a, b, text in items:
        if b - a < 0.15 or not text.strip():
            continue
        t = text.replace("\\", "\\\\").replace("{", "(").replace("}", ")").replace("\n", " ")
        body.append(f"Dialogue: 0,{_ass_ts(a)},{_ass_ts(b)},Default,,0,0,0,,{t}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(head + body) + "\n")


def _decode_audio(path, sr=8000):
    if np is None:
        return None, sr
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vn", "-ac", "1",
                        "-ar", str(sr), "-f", "s16le", "-"], capture_output=True)
    buf = p.stdout
    if not buf:
        return None, sr
    return np.frombuffer(buf, dtype=np.int16).astype(np.float32) / 32768.0, sr


def _decode_motion(path, w=128, h=72, fps=2):
    if np is None:
        return None, fps
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vf",
                        f"fps={fps},scale={w}:{h},format=gray", "-f", "rawvideo", "-"],
                       capture_output=True)
    buf = p.stdout
    n = len(buf) // (w * h)
    if n < 2:
        return None, fps
    arr = np.frombuffer(buf[:n * w * h], dtype=np.uint8).reshape(n, h, w).astype(np.float32)
    diff = np.abs(np.diff(arr, axis=0)).mean(axis=(1, 2))
    return diff, fps


def _window_scores(clip, win=10.0, hop=2.0):
    dur = clip.get("duration") or 0
    if dur <= win:
        return []
    audio, sr = _decode_audio(clip["path"])
    motion, mfps = _decode_motion(clip["path"])
    if audio is None and motion is None:
        return []
    rows = []
    s = 0.5
    while s + win <= dur - 0.5:
        av = mv = 0.0
        if audio is not None and len(audio):
            i0, i1 = int(s * sr), min(len(audio), int((s + win) * sr))
            if i1 > i0:
                seg = audio[i0:i1]
                av = float(np.sqrt(np.mean(seg * seg)))
        if motion is not None and len(motion):
            j0 = max(0, int((s - 0.5) * mfps))
            j1 = min(len(motion), int((s + win - 0.5) * mfps))
            if j1 > j0:
                mv = float(np.mean(motion[j0:j1]))
        rows.append({"start": float(s), "audio": av, "motion": mv})
        s += hop
    return rows


def _silence_points(path, noise="-30dB", min_sil=0.30):
    """静音区间中点：优先作为“台词完整处”的切点。"""
    cmd = [FFMPEG, "-v", "info", "-i", path,
           "-af", f"silencedetect=noise={noise}:d={min_sil}", "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True)
    txt = (p.stderr or b"").decode("utf-8", "replace")
    starts = [float(x) for x in re.findall(r"silence_start:\s*(-?[\d.]+)", txt)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*(-?[\d.]+)", txt)]
    pts = []
    for s in starts:
        nxt = [e for e in ends if e > s]
        if nxt:
            e = min(nxt)
            if e - s >= min_sil:
                pts.append((s + e) / 2.0)
    return pts


def _scene_points(path, thresh=0.35):
    """镜头切换点：静音不足时兜底，尽量落在句间而不是句中。"""
    cmd = [FFMPEG, "-v", "info", "-i", path, "-an",
           "-vf", f"select='gt(scene,{thresh})',metadata=print", "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True)
    txt = (p.stderr or b"").decode("utf-8", "replace")
    return [float(x) for x in re.findall(r"pts_time:\s*([\d.]+)", txt)]


def _cut_points(clip):
    """静音中点切点；ASR 不可用时也只按停顿切，绝不切进句子。"""
    dur = clip.get("duration") or 0
    pts = _silence_points(clip["path"])
    pts = [p for p in pts if 0.5 < p < dur - 0.5]
    pts = [0.0] + pts + [dur]
    pts.sort()
    merged = []
    for p in pts:
        if not merged or p - merged[-1] >= 0.4:
            merged.append(p)
    return merged


_WHISPER = None


def _whisper():
    global _WHISPER
    if _WHISPER is None:
        from faster_whisper import WhisperModel
        name = os.environ.get("RECREATE_ASR_MODEL", "medium")
        dev = os.environ.get("RECREATE_ASR_DEVICE", "cpu")
        _WHISPER = WhisperModel(name, device=dev,
                                compute_type="int8" if dev == "cpu" else "float16")
    return _WHISPER


def _load_audio16k(path):
    p = subprocess.run([FFMPEG, "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000",
                        "-f", "s16le", "-"], capture_output=True)
    return np.frombuffer(p.stdout, dtype=np.int16).astype(np.float32) / 32768.0


def _asr_sentences(clip):
    """Whisper 句级时间戳（带缓存）。失败返回 []。"""
    path = clip["path"]
    cache = path + ".asr.json"
    if os.path.isfile(cache):
        try:
            data = json.load(open(cache, encoding="utf-8"))
            if data.get("sentences"):
                return data["sentences"]
        except Exception:
            pass
    try:
        audio = _load_audio16k(path)
        if not len(audio):
            return []
        print("ASR start:", os.path.basename(path), flush=True)
        model = _whisper()
        segs, _ = model.transcribe(audio, language="zh", vad_filter=True, beam_size=1,
                                   condition_on_previous_text=False,
                                   initial_prompt="以下是简体中文短剧对白，请用简体中文输出。")
        out = []
        for s in segs:
            t = (s.text or "").strip()
            if not t:
                continue
            out.append({"start": round(float(s.start), 2), "end": round(float(s.end), 2), "text": t})
        # 合并被切碎的短片段（同一句被 VAD 切两半）
        merged = []
        for s in out:
            if merged and (s["end"] - s["start"] < 0.8 or len(s["text"]) < 4) \
                    and s["start"] - merged[-1]["end"] < 0.35:
                merged[-1]["end"] = s["end"]
                merged[-1]["text"] += s["text"]
            else:
                merged.append(dict(s))
        try:
            json.dump({"model": os.environ.get("RECREATE_ASR_MODEL", "medium"),
                       "sentences": merged},
                      open(cache, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass
        print("ASR done:", os.path.basename(path), len(merged), "sentences", flush=True)
        return merged
    except Exception as e:
        print("ASR failed:", path, e, flush=True)
        return []


def _sentence_windows(sentences, lo, hi):
    """由连续完整句组成的窗口，两端都落在句子边界。"""
    wins = []
    for i in range(len(sentences)):
        t0 = sentences[i]["start"]
        for j in range(i, len(sentences)):
            t1 = sentences[j]["end"]
            d = t1 - t0
            if d > hi:
                break
            if d >= lo:
                wins.append({"a": t0, "b": t1, "subs": sentences[i:j + 1]})
    return wins


def plan_highlights(clips, total, seg_len, seed):
    """按句级时间戳选段：每段起止都落在完整句子边界，杜绝切断台词。"""
    rnd = random.Random(seed)
    n = max(6, int(round(total / seg_len)))
    lo, hi = max(6.5, seg_len - 2.5), seg_len + 2.5
    feats = []
    for clip in clips:
        audio, sr = _decode_audio(clip["path"])
        motion, mfps = _decode_motion(clip["path"])
        feats.append({"clip": clip, "a": audio, "sr": sr,
                      "m": motion, "mf": mfps, "cuts": _cut_points(clip)})

    def score(f, a, b):
        av = mv = 0.0
        A, sr = f["a"], f["sr"]
        if A is not None and len(A):
            i0, i1 = int(a * sr), min(len(A), int(b * sr))
            if i1 > i0:
                av = float(np.sqrt(np.mean(A[i0:i1] ** 2)))
        M, mf = f["m"], f["mf"]
        if M is not None and len(M):
            j0, j1 = max(0, int((a - 0.5) * mf)), min(len(M), int((b - 0.5) * mf))
            if j1 > j0:
                mv = float(np.mean(M[j0:j1]))
        return av, mv

    asr_ok = False
    cand = []
    for ci, f in enumerate(feats):
        sens = _asr_sentences(f["clip"])
        wins = _sentence_windows(sens, lo, hi) if sens else []
        if wins:
            asr_ok = True
        if not wins:                      # ASR 不可用时退回停顿/镜头切点
            cuts = f["cuts"]
            for i, a in enumerate(cuts):
                for b in cuts[i + 1:]:
                    d = b - a
                    if d < lo:
                        continue
                    if d > hi:
                        break
                    wins.append({"a": a, "b": b, "subs": []})
        for w in wins:
            av, mv = score(f, w["a"], w["b"])
            cand.append((av, mv, ci, w["a"], w["b"], w["b"] - w["a"], w["subs"]))

    chosen = []
    if cand:
        au = sorted(c[0] for c in cand)
        mo = sorted(c[1] for c in cand)
        pa = au[int(len(au) * 0.9)] or 1.0
        pm = mo[int(len(mo) * 0.9)] or 1.0
        scored = sorted(((0.6 * min(1.0, c[0] / pa) + 0.4 * min(1.0, c[1] / pm),
                          c[2], c[3], c[4], c[5], c[6]) for c in cand), reverse=True)
        per_clip_cap = max(3, n // len(clips) + 2)
        used = {i: [] for i in range(len(clips))}
        for item in scored:
            sc, ci, a, b, d, subs = item
            if len(chosen) >= n:
                break
            if len(used[ci]) >= per_clip_cap:
                continue
            if any(not (a >= u2 or b <= u1) for u1, u2 in used[ci]):
                continue
            used[ci].append((a, b))
            chosen.append(item)
        # 时长不够就再补（仍取完整句窗口）
        raw = sum(c[4] for c in chosen)
        for item in scored:
            if raw >= total * 0.97:
                break
            sc, ci, a, b, d, subs = item
            if any(x is item for x in chosen):
                continue
            if len(used[ci]) >= per_clip_cap + 2:
                continue
            if any(not (a >= u2 or b <= u1) for u1, u2 in used[ci]):
                continue
            used[ci].append((a, b))
            chosen.append(item)
            raw += d
    # 极少见兜底：没有任何候选
    while len(chosen) < n:
        ci = rnd.randrange(len(clips))
        dur = feats[ci]["clip"].get("duration") or (seg_len * 2)
        st = rnd.uniform(0.5, max(0.6, dur - seg_len - 1))
        chosen.append((rnd.uniform(0.3, 0.6), ci, round(st, 2), round(st + seg_len, 2), seg_len, []))

    chosen.sort(key=lambda x: x[0])       # 由弱到强
    # 用统一缩放把总时长压到 total 附近，保住句子边界
    raw = sum(c[4] for c in chosen) or 1.0
    scale = max(0.85, min(1.15, raw / max(1.0, total)))
    segments = []
    for i, (sc, ci, a, b, d, subs) in enumerate(chosen):
        base = [1.0, 1.04, 0.96][i % 3]
        speed = round(max(0.85, min(1.15, base * scale)), 4)
        out_dur = round(d / speed, 3)
        segments.append({"clip": clips[ci]["path"], "start": round(float(a), 2),
                         "dur": out_dur, "take": round(float(d), 3),
                         "speed": speed, "has_audio": clips[ci].get("has_audio", False),
                         "score": round(float(sc), 3),
                         "subs": [{"start": s["start"], "end": s["end"], "text": s["text"]}
                                  for s in subs],
                         "sentence_aligned": bool(subs) or asr_ok,
                         "cut_aligned": bool(subs) or asr_ok})
    return segments


def plan_segments(clips, total, seg_len, seed):
    rnd = random.Random(seed)
    n = max(6, int(round(total / seg_len)))
    seg_len = total / n
    segments = []
    for i in range(n):
        clip = clips[i % len(clips)]
        speed = [1.0, 1.04, 0.96][i % 3]
        take = seg_len * speed
        max_start = max(1.0, clip["duration"] - take - 2.0)
        start = rnd.uniform(1.0, max_start)
        segments.append({"clip": clip["path"], "start": round(start, 2),
                         "dur": seg_len, "take": round(take, 2),
                         "speed": speed, "has_audio": clip.get("has_audio", False)})
    return segments


def render_segment(seg, idx, out_path, W, H, workdir, mirror=False, keep_src_subs=False,
                   fps=30, zoom=1.0, eq_c=1.05, eq_s=1.12, vig=0.52, noise=4):
    """逐段渲染；fps/zoom/调色/颗粒可随机，用于让每条成片都不一样。"""
    flip = "hflip," if (mirror and idx % 2) else ""
    spd = seg.get("speed", 1.0)
    crop = "crop=iw:ih*0.72:0:0," if (seg.get("subs") and not keep_src_subs) else ""
    if zoom > 1.001:
        fit = f"scale={int(W * zoom)}:{int(H * zoom)}:force_original_aspect_ratio=increase,crop={W}:{H}"
    else:
        fit = f"scale={W}:{H}:force_original_aspect_ratio=decrease"
        if crop:
            fit += f",crop={W}:{H}"
    speed_pre = f"setpts=(1/{spd:.4f})*PTS," if abs(spd - 1.0) > 0.001 else ""
    vf = (
        f"[0:v]{speed_pre}fps={fps},split=2[bg][fg];"
        f"[bg]scale={max(2, W // 4)}:{max(2, H // 4)},gblur=sigma=12,scale={W}:{H},setsar=1[bgv];"
        f"[fg]{crop}{fit},{flip}setsar=1[fgv];"
        f"[bgv][fgv]overlay=({W}-w)/2:({H}-h)/2,"
        f"eq=contrast={eq_c:.3f}:saturation={eq_s:.3f},vignette=PI*{vig:.3f},"
        f"noise=alls={noise}:allf=t+u,"
        "tpad=stop_mode=clone:stop_duration=1,format=yuv420p[v]"
    )
    dur = seg["dur"]
    cmd = [FFMPEG, "-y", "-ss", str(seg["start"]), "-t", str(seg["take"]), "-i", seg["clip"]]
    has_audio = seg.get("has_audio")
    if has_audio:
        af = (f"atempo={spd:.3f}," if abs(spd - 1.0) > 0.001 else "")
        af += f"aresample=44100,apad,atrim=0:{dur:.3f},asetpts=PTS-STARTPTS"
        cmd += ["-filter_complex", vf + f";[0:a]{af}[a]", "-map", "[v]", "-map", "[a]"]
    else:
        cmd += ["-f", "lavfi", "-t", str(dur), "-i", "anullsrc=r=44100:cl=stereo"]
        cmd += ["-filter_complex", vf, "-map", "[v]", "-map", "1:a"]
    frames = max(1, int(round(dur * fps)))
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
            "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
            "-t", f"{dur + 0.2:.3f}", "-frames:v", str(frames), "-r", str(fps),
            "-video_track_timescale", "90000", out_path]
    rc, _, err = run(cmd, cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"segment {idx} failed: {err[-2000:]}")
    return out_path


def render_intro(cover, out_path, W, H, workdir, secs=2.5):
    """封面片头：铺满画布 + 缓慢推近，不带字幕。"""
    frames = max(15, int(round(secs * 30)))
    vf = (
        f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
        f"zoompan=z='min(zoom+0.0015,1.08)':d={frames}:s={W}x{H}:fps=30,"
        f"eq=contrast=1.03:saturation=1.08,format=yuv420p[v]"
    )
    cmd = [FFMPEG, "-y", "-i", cover,
           "-f", "lavfi", "-t", str(secs), "-i", "anullsrc=r=44100:cl=stereo",
           "-filter_complex", vf, "-map", "[v]", "-map", "1:a", "-shortest",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-c:a", "aac", "-b:a", "128k", "-ar", "44100", "-ac", "2",
           "-t", str(secs), "-video_track_timescale", "90000", out_path]
    rc, _, err = run(cmd, cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"intro failed: {err[-600:]}")
    return out_path


def concat_segments(paths, out_path, workdir):
    lst = os.path.join(workdir, "concat.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in paths:
            f.write("file '" + p.replace("\\", "/") + "'\n")
    rc, _, err = run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", lst,
                      "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                      "-ar", "44100", "-ac", "2", "-fflags", "+genpts", out_path], cwd=workdir)
    if rc != 0:
        raise RuntimeError(f"concat failed: {err[-600:]}")
    return out_path


def final_render(timeline, narration, bgm, subs, out_path, W, H, watermark, total, workdir,
                 wm_font=None, wm_margin=24):
    inputs = [FFMPEG, "-y", "-i", timeline]
    n = 1
    nar_idx = None
    bgm_idx = None
    if narration and os.path.isfile(narration):
        inputs += ["-i", narration]
        nar_idx = n; n += 1
    if bgm and os.path.isfile(bgm):
        inputs += ["-stream_loop", "-1", "-i", bgm]
        bgm_idx = n; n += 1

    vf = []
    # 烧录字幕时先铺一条半透明字幕条，盖住源片自带字幕（避免重影）
    if subs and os.path.isfile(subs) and subs.lower().endswith(".ass"):
        pass  # 源字幕用画面裁切处理，不再压黑条
    wm = (watermark or "").replace(":", "\\:").replace("'", "")
    if wm:
        vf.append(
            f"drawtext=fontfile='{FONT_ESC}':text='{wm}':fontsize={wm_font or max(14, H // 28)}:"
            f"fontcolor=white@0.55:x=w-tw-{wm_margin}:y={wm_margin}:shadowcolor=black@0.45:shadowx=1:shadowy=1"
        )
    # libass 以 288 行为基准缩放 force_style 的单位；这里换算回像素意图
    scale = 288.0 / H
    fs_units = max(6, round(max(22, H // 36) * scale))
    mv_units = max(8, round(max(60, H // 8) * scale))
    ol_units = max(1, round(3 * scale))
    sub_style = (f"FontName=Microsoft YaHei,FontSize={fs_units},"
                 "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,BorderStyle=1,"
                 f"Outline={ol_units},Shadow=0,MarginV={mv_units},Alignment=2")
    if subs and os.path.isfile(subs):
        if subs.lower().endswith(".ass"):
            vf.append(f"subtitles={os.path.basename(subs)}")
        else:
            vf.append(f"subtitles={os.path.basename(subs)}:force_style='{sub_style}'")
    vf.append("format=yuv420p")
    vchain = ",".join(vf) if vf else "null"

    if nar_idx is not None and bgm_idx is not None:
        afilter = (
            f"[{nar_idx}:a]volume=1.0,aresample=44100[nar];"
            f"[{bgm_idx}:a]volume=0.16,atrim=0:{total},asetpts=PTS-STARTPTS[bgm];"
            "[nar]asplit=2[n1][key];"
            "[bgm][key]sidechaincompress=threshold=0.03:ratio=12:attack=15:release=350[duck];"
            "[0:a]volume=0.7[orig];"
            f"[n1][duck][orig]amix=inputs=3:duration=longest:normalize=0,apad,atrim=0:{total}[a]"
        )
    elif bgm_idx is not None:
        # 原声全音量保留；BGM 低音量并用原声做侧链闪避，保证台词清楚
        afilter = (f"[{bgm_idx}:a]volume=0.12,atrim=0:{total},asetpts=PTS-STARTPTS[bgm];"
                   "[0:a]volume=1.0,asplit=2[orig][key];"
                   "[bgm][key]sidechaincompress=threshold=0.02:ratio=10:attack=10:release=300[duck];"
                   f"[orig][duck]amix=inputs=2:duration=longest:normalize=0,apad,atrim=0:{total}[a]")
    else:
        afilter = "[0:a]volume=1.0[a]"

    cmd = inputs + [
        "-filter_complex", f"[0:v]{vchain}[v];{afilter}",
        "-map", "[v]", "-map", "[a]",
        "-t", str(total),
        "-c:v", "libx264", "-preset", "medium", "-crf", "19",
        "-c:a", "aac", "-b:a", "192k", "-ar", "44100", "-ac", "2",
        "-movflags", "+faststart", "-pix_fmt", "yuv420p", out_path,
    ]
    rc, _, err = run(cmd, cwd=workdir, timeout=10800)
    if rc != 0:
        raise RuntimeError(f"final render failed: {err[-800:]}")
    return out_path


def pick_cover(files):
    """封面命名不统一：封面/cover/海报/任意图片。"""
    imgs = [f for f in files if os.path.splitext(f)[1].lower() in (".jpg", ".jpeg", ".png", ".webp")]
    for f in imgs:
        if any(k in f.lower() for k in ("封面", "cover", "海报", "poster")):
            return f
    return imgs[0] if imgs else None


def render_one(folder, aspect="9:16", duration=180, watermark="", voice="zh-CN-YunxiNeural",
               no_tts=True, force=False, suffix="", mirror=False, cover_intro=True, keep_src_subs=False, subtitles=False, seed=0):
    title = os.path.basename(folder.rstrip("\\/"))
    title = re.sub(r"^\d+\.\s*", "", title)
    out_path = os.path.join(folder, f"{title}_二创_3min{suffix}.mp4")
    report_path = os.path.join(folder, f"{title}_二创_报告{suffix}.json")
    if os.path.isfile(out_path) and not force:
        return {"status": "skip", "folder": folder, "output": out_path}

    clips = []
    for i in (1, 2, 3):
        p = os.path.join(folder, f"{i}.mp4")
        if os.path.isfile(p):
            info = probe(p)
            info["path"] = p
            if info.get("has_audio"):     # 必须有原声：原音轨要像字幕一样保留
                clips.append(info)
    if not clips:
        return {"status": "no_audio", "folder": folder}

    W, H = parse_aspect(aspect)
    seed = int(seed or random.randrange(1, 10 ** 9))
    rnd = random.Random(seed)
    duration_eff = round(duration * rnd.uniform(0.90, 1.10), 2)
    fps = rnd.choice([25, 30])
    zoom = round(rnd.uniform(1.0, 1.12), 3)          # 画面缩放，连带源字幕视觉大小变化
    eq_c = round(rnd.uniform(1.03, 1.09), 3)
    eq_s = round(rnd.uniform(1.06, 1.18), 3)
    vig = round(rnd.uniform(0.145, 0.185), 3)
    noise = rnd.randint(2, 7)
    seg_len = round(rnd.uniform(8.5, 11.5), 2)
    wm_font = int(round(H * rnd.uniform(1 / 38, 1 / 22)))
    wm_margin = rnd.randint(16, 36)
    sub_fs = round(rnd.uniform(0.036, 0.058), 4)      # 烧录字幕字号（--subtitles 时生效）
    files = os.listdir(folder)
    cover = pick_cover(files) if cover_intro else None
    intro_secs = round(rnd.uniform(2.0, 3.0), 2) if cover else 0.0
    content_total = max(30.0, duration_eff - intro_secs)
    with tempfile.TemporaryDirectory(prefix="recreate_") as work:
        paths = []
        if cover:
            intro = os.path.join(work, "intro.mp4")
            render_intro(os.path.join(folder, cover), intro, W, H, work, intro_secs)
            paths.append(intro)
        segs = plan_highlights(clips, content_total, seg_len, seed)
        for i, s in enumerate(segs):
            seg_path = os.path.join(work, f"seg_{i:03d}.mp4")
            render_segment(s, i, seg_path, W, H, work, mirror, keep_src_subs or not subtitles,
                           fps=fps, zoom=zoom, eq_c=eq_c, eq_s=eq_s, vig=vig, noise=noise)
            paths.append(seg_path)
        timeline = concat_segments(paths, os.path.join(work, "timeline.mp4"), work)
        content_actual = sum(float(s["dur"]) for s in segs)
        total_actual = round(intro_secs + content_actual, 2)

        commentary = make_commentary(title, seed) if not no_tts else ""
        narration = None
        tts_err = ""
        if not no_tts:
            narration = os.path.join(work, "narration.mp3")
            ok, tts_err = tts(commentary, narration, voice)
            if not ok:
                narration = None

        nar_dur = 0.0
        if narration:
            nar_dur = probe(narration).get("duration", 0.0)

        subs = None
        subtitle_count = 0
        if narration and nar_dur > 5:
            sentences = split_sentences(commentary)
            subs = os.path.join(work, "subs.srt")
            write_srt(sentences, min(nar_dur, total_actual), subs)
            subtitle_count = len(sentences)
        elif subtitles and any(s.get("subs") for s in segs):
            items = []
            offset = intro_secs
            for s in segs:
                spd = float(s.get("speed") or 1.0)
                for sub in s.get("subs") or []:
                    items.append(((sub["start"] - s["start"]) / spd + offset,
                                  (sub["end"] - s["start"]) / spd + offset,
                                  sub["text"]))
                offset += float(s["dur"])
            subs = os.path.join(work, "subs.ass")
            write_ass(items, W, H, subs, fs_factor=sub_fs)
            subtitle_count = len(items)

        ensure_bgm()
        mood, bgm = pick_bgm(title)
        final_render(timeline, narration, bgm, subs, out_path, W, H, watermark, total_actual, work,
                     wm_font=wm_font, wm_margin=wm_margin)

        info = probe(out_path)
        report = {
            "folder": folder, "title": title, "output": out_path,
            "aspect": aspect, "size": f"{W}x{H}",
            "duration": round(info.get("duration", 0), 2),
            "width": info.get("width"), "height": info.get("height"),
            "watermark": watermark, "bgm": mood,
            "seed": seed, "fps": fps, "zoom": zoom,
            "duration_target": duration_eff, "segment_len": seg_len,
            "eq_contrast": eq_c, "eq_saturation": eq_s, "noise": noise,
            "watermark_font": wm_font, "watermark_margin": wm_margin,
            "highlight": True,
            "highlight_scores": [s.get("score") for s in segs],
            "cut_aligned": all(s.get("cut_aligned") for s in segs),
            "sentence_aligned": all(s.get("sentence_aligned") for s in segs),
            "original_audio": True,
            "burned_subtitles": bool(subtitle_count),
            "subtitle_count": subtitle_count,
            "asr_model": os.environ.get("RECREATE_ASR_MODEL", "medium"),
            "src_subs_cropped": bool(subtitle_count and not keep_src_subs and not narration),
            "segment_durations": [round(float(s["dur"]), 2) for s in segs],
            "cover_file": cover or "",
            "cover_intro": bool(cover),
            "narration_chars": len(commentary) if narration else 0,
            "tts": ("edge-tts" if narration else ("disabled" if no_tts else f"failed: {tts_err[:200]}")),
            "segments": len(segs), "clips": len(clips),
            "compliance": {
                "multi_clip": len(clips) >= 3,
                "effects": True,
                "mirror": bool(mirror),
                "watermark": bool(watermark),
                "commentary": bool(narration),
                "subtitles": bool(subs),
                "bgm": bool(bgm),
            },
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=1)
        return {"status": "ok", **report}


def main():
    ap = argparse.ArgumentParser(prog="recreate.py")
    ap.add_argument("--version", action="version", version=f"recreate-studio {__version__}")
    ap.add_argument("--folder")
    ap.add_argument("--root")
    ap.add_argument("--aspect", default="9:16")
    ap.add_argument("--duration", type=float, default=180)
    ap.add_argument("--watermark", default="")
    ap.add_argument("--voice", default="zh-CN-YunxiNeural")
    ap.add_argument("--tts", action="store_true", help="加 AI 解说旁白（默认关闭，只做高燃剪辑）")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--suffix", default="")
    ap.add_argument("--mirror", action="store_true",
                    help="隔段镜像（默认关闭：源片硬字幕会被镜像成反字）")
    ap.add_argument("--no-cover", action="store_true", help="不用封面做片头（默认会加）")
    ap.add_argument("--seed", type=int, default=0, help="随机种子；0=每条都随机，固定值可复现")
    ap.add_argument("--setup-bgm", action="store_true", help="只准备 BGM 库（下载/补齐后退出）")
    ap.add_argument("--bgm-limit", type=int, default=0)
    ap.add_argument("--bgm-force", action="store_true")
    ap.add_argument("--keep-src-subs", action="store_true", help="不裁掉源片底部硬字幕（默认裁掉，避免与烧录字幕重影）")
    ap.add_argument("--subtitles", action="store_true", help="额外烧录 ASR 字幕（默认关闭，保留源片硬字幕）")
    a = ap.parse_args()

    if a.setup_bgm:
        ensure_bgm(a.bgm_limit, a.bgm_force)
        return

    targets = []
    if a.folder:
        targets = [a.folder]
    elif a.root:
        for d in sorted(os.listdir(a.root)):
            p = os.path.join(a.root, d)
            if os.path.isdir(p) and os.path.isfile(os.path.join(p, "1.mp4")):
                targets.append(p)
    else:
        ap.error("需要 --folder 或 --root")

    if a.limit:
        targets = targets[:a.limit]

    results = []
    for i, t in enumerate(targets, 1):
        try:
            r = render_one(t, a.aspect, a.duration, a.watermark, a.voice,
                           no_tts=not a.tts, force=a.force, suffix=a.suffix,
                           mirror=a.mirror, cover_intro=not a.no_cover,
                           keep_src_subs=a.keep_src_subs, subtitles=a.subtitles, seed=a.seed)
        except Exception as e:
            r = {"status": "error", "folder": t, "error": str(e)[-800:]}
        results.append(r)
        print(json.dumps({"i": i, "total": len(targets), **{k: r.get(k) for k in
                          ("status", "title", "output", "duration", "size", "error")}},
                         ensure_ascii=False), flush=True)

    ok = sum(1 for r in results if r.get("status") in ("ok", "skip"))
    print(json.dumps({"done": len(results), "ok": ok,
                      "fail": len(results) - ok}, ensure_ascii=False))


if __name__ == "__main__":
    main()

